#!/bin/ash
echo "ap10 up and initialize"
#Use this apxx.sh, we can build an AP_5G, change lan ip to 192.168.xx.xx, close
#dhcp, and build the wwan iface for clientAP.

# build ap
## arm for Linksys use radio0 as 5GHz AP.
uci set wireless.radio0.channel=36
uci set wireless.radio0.txpower=2
uci set wireless.radio0.country=CN
uci set wireless.radio0.disabled=0

## shut down 2.4G AP
uci set wireless.radio1.disabled=1

## delete all wifi-iface
## must be [1][0]
uci delete wireless.@wifi-iface[1]
uci delete wireless.@wifi-iface[0]

## add AP interface
uci add wireless wifi-iface
uci set wireless.@wifi-iface[0].device=radio0
uci set wireless.@wifi-iface[0].mode=ap
uci set wireless.@wifi-iface[0].ssid=openwrt10
uci set wireless.@wifi-iface[0].encryption=none
uci set wireless.@wifi-iface[0].network=lan
uci commit wireless

# build wwan & change lan
uci set network.wwan=interface
uci set network.wwan._orig_ifname=wlan0
uci set network.wwan._orig_bridge=false
uci set network.wwan.proto=static
uci set network.wwan.netmask=255.255.255.0

uci set network.lan.ipaddr=192.168.10.10
uci commit network

# change firewall
uci set firewall.@zone[0].forward=ACCEPT
uci set firewall.@zone[0].network="lan"
uci set firewall.@zone[1].forward=ACCEPT
uci set firewall.@zone[1].network="wan wwan"
uci commit firewall

# change lan_dhcp
uci delete dhcp.lan.leasetime
uci delete dhcp.lan.limit
uci delete dhcp.lan.start
uci set dhcp.lan.ignore=1
uci set dhcp.lan.ra_management=1
uci commit dhcp

# restart
/etc/init.d/dnsmasq restart
sleep 1
/etc/init.d/network restart
