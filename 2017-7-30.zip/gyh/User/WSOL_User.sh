#!/bin/ash
# This is the main shell for User Terminal. 

echo "User Main Shell"
# Enable shell files
chmod +x ./*.sh
chmod +x ./chooserouter-user
chmod +x ./tcpclient

# Initialize
./ap10.sh

# Find and choose router
./findrouter.sh
./chooserouter-user /tmp/routerlist.txt >| /tmp/bestrouter.txt
sleep 1
# join in
./clientAP.sh

# Run TCP client
./tcpclient