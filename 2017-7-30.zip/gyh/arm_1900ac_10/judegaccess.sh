#!/bin/ash
# This file is to judge whether the access point is an openwrt device or normal device or no access.
# Return value: openwrt device (1), normal device (2), no access (0)

FLAG_A=`iw dev wlan0 station dump | egrep '^Station|inactive' | sed 's/Station //; s/ (on wlan0)//; s/\tinactive time:\t//'`

if [ -z $FLAG_A ]; then
	echo 0
else
	echo $FLAG_A
fi
