#!/bin/ash
# To creat LPM file.

echo 'openwrt10' >| /tmp/LPM.txt

iw dev wlan0 info | grep 'addr' | sed 's/.*addr //' >> /tmp/LPM.txt

head -n 1 /tmp/bestrouter.txt >> /tmp/LPM.txt

echo '----------' >> /tmp/LPM.txt
