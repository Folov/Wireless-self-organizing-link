#!/bin/ash
# This is the main shell for User Terminal. 

echo "User Main Shell"
# Enable shell files
chmod +x ./*.sh
chmod +x ./chooserouter-user
chmod +x ./tcpclient

# Initialize
./ap10.sh

# Find and choose router
./findrouter.sh
./chooserouter-user /tmp/routerlist.txt >| /tmp/bestrouter.txt
sleep 1
# join in
./clientAP.sh

gate=`head -n 1 /tmp/bestrouter.txt | sed 's/openwrt//'`
GATE_IP=192.168.$gate.$gate
# Run TCP client, send LPM to server
./creat_LPM_file.sh
./tcpcli $GATE_IP /tmp/LPM.txt
