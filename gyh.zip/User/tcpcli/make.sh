#!/bin/ash

export  PATH=/WorkSpace/code/openwrt/openwrt_WRT1900ac/openwrt/staging_dir/toolchain-arm_cortex-a9+vfpv3_gcc-4.8-linaro_uClibc-0.9.33.2_eabi/bin:$PATH
export  STAGING_DIR=/home/guest/work_gyh/staging_dir

./make