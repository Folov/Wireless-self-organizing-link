#!/bin/bash

export PATH=/WorkSpace/code/openwrt/openwrt_LEDE_WRT3200ac/source/staging_dir/toolchain-arm_cortex-a9+vfpv3_gcc-5.4.0_musl_eabi/bin:$PATH
export  STAGING_DIR=/home/guest/work_gyh/staging_dir

make